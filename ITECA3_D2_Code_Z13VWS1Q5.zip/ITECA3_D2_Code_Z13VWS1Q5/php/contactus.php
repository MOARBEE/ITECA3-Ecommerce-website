<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hamzauto";


//Database connection
$conn = new mysqli($servername, $username, $password, $dbname);

        $name = $_POST['nameCont'];
        $emailAddress = $_POST['emailCont'];
        $subject = $_POST['subjectCont'];
        $text = $_POST['textCont'];

       
        $query = "insert into contactus(name,email,subject,text) values('$name', '$emailAddress', '$subject', '$text')";

        $run = mysqli_query($conn,$query) or die(mysqli_error($conn));

        if($run){
            echo '<script type="text/javascript"> alert("Thank you! Your response has been submitted and we will get back to you soon ;)") </script>';
            echo '<script> window.location.replace("http://localhost/ITECA3_D2_Code_Z13VWS1Q5/contact.html"); </script>';
        }

        else{
            echo '<script type="text/javascript"> alert("uh oh, your response was not submitted, please try again") </script>';
            echo '<script> window.location.replace("http://localhost/ITECA3_D2_Code_Z13VWS1Q5/contact.html"); </script>';
        }                
?>